/* ---------- File Manager ---------- */
var elf = $('.file-manager').elfinder({
	url : 'assets/misc/elfinder-connector/connector.php'  // connector URL (REQUIRED)
}).elfinder('instance');